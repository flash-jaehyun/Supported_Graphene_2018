import cPickle as  pickle


with open("job_dataframe.pickle", "rb") as fle:
    data = pickle.load(fle)
