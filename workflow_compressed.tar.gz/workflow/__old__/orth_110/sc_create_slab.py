from ase.build import bcc110

# ase.build.bcc110


atoms = bcc110("Fe", (2,2,2), a=)
