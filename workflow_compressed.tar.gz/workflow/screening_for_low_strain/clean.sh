rm -r 01_data

rm comb.traj
rm graph.traj
rm data.csv

rm master_data.pickle
#rm -r bcc_100
#rm -r bcc_110
#rm -r bcc_111
#rm -r fcc_100
#rm -r fcc_110
#rm -r fcc_111
